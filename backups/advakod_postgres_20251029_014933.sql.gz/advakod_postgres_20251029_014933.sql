--
-- PostgreSQL database dump
--

\restrict tQZ44qwhrr7OfuclNxqua3IKbuIRMignf1vOUid4Ca13C1nYa8J3h3Fb5yjMKoS

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-10-29 01:49:33 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 24749)
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    session_id integer NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    message_metadata jsonb,
    audio_url character varying(500),
    audio_duration integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 220 (class 1259 OID 24748)
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3467 (class 0 OID 0)
-- Dependencies: 220
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- TOC entry 219 (class 1259 OID 24735)
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 218 (class 1259 OID 24734)
-- Name: chat_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3468 (class 0 OID 0)
-- Dependencies: 218
-- Name: chat_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_sessions_id_seq OWNED BY public.chat_sessions.id;


--
-- TOC entry 217 (class 1259 OID 24718)
-- Name: token_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_balances (
    id integer NOT NULL,
    user_id integer NOT NULL,
    balance integer DEFAULT 1000 NOT NULL,
    total_earned integer DEFAULT 0 NOT NULL,
    total_spent integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 216 (class 1259 OID 24717)
-- Name: token_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.token_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3469 (class 0 OID 0)
-- Dependencies: 216
-- Name: token_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.token_balances_id_seq OWNED BY public.token_balances.id;


--
-- TOC entry 215 (class 1259 OID 24698)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    is_active boolean DEFAULT true,
    is_premium boolean DEFAULT false,
    is_admin boolean DEFAULT false,
    subscription_type character varying(50) DEFAULT 'free'::character varying,
    subscription_expires timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    company_name character varying(255),
    legal_form character varying(100),
    inn character varying(12),
    ogrn character varying(15),
    two_factor_enabled boolean DEFAULT false,
    two_factor_secret character varying(32),
    backup_codes text
);


--
-- TOC entry 214 (class 1259 OID 24697)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3292 (class 2604 OID 24752)
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- TOC entry 3289 (class 2604 OID 24738)
-- Name: chat_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions ALTER COLUMN id SET DEFAULT nextval('public.chat_sessions_id_seq'::regclass);


--
-- TOC entry 3283 (class 2604 OID 24721)
-- Name: token_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_balances ALTER COLUMN id SET DEFAULT nextval('public.token_balances_id_seq'::regclass);


--
-- TOC entry 3275 (class 2604 OID 24701)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3461 (class 0 OID 24749)
-- Dependencies: 221
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, session_id, role, content, message_metadata, audio_url, audio_duration, created_at) FROM stdin;
\.


--
-- TOC entry 3459 (class 0 OID 24735)
-- Dependencies: 219
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_sessions (id, user_id, title, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3457 (class 0 OID 24718)
-- Dependencies: 217
-- Data for Name: token_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.token_balances (id, user_id, balance, total_earned, total_spent, created_at, updated_at) FROM stdin;
1	1	1000	0	0	2025-10-29 01:23:30.343515+00	2025-10-29 01:23:30.343515+00
2	2	1000	0	0	2025-10-29 01:23:30.343515+00	2025-10-29 01:23:30.343515+00
\.


--
-- TOC entry 3455 (class 0 OID 24698)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, username, hashed_password, full_name, is_active, is_premium, is_admin, subscription_type, subscription_expires, created_at, updated_at, company_name, legal_form, inn, ogrn, two_factor_enabled, two_factor_secret, backup_codes) FROM stdin;
2	vitaly@advacodex.com	vitaly_admin	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4/LewdBPj4	Vitaly Admin	t	f	t	free	\N	2025-10-29 01:23:30.343515+00	2025-10-29 01:23:30.343515+00	\N	\N	\N	\N	f	\N	\N
1	aziz@bagbekov.ru	aziz_admin	$2b$12$OFKQhk52i9IjqQsectnVMei7tsgyulhx/jHoaKk8fK9T7XhlU5vr.	Aziz Bagbekov (Superuser)	t	f	t	free	\N	2025-10-29 01:23:30.343515+00	2025-10-29 01:23:30.343515+00	\N	\N	\N	\N	f	\N	\N
\.


--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 220
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_messages_id_seq', 1, false);


--
-- TOC entry 3472 (class 0 OID 0)
-- Dependencies: 218
-- Name: chat_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_sessions_id_seq', 1, false);


--
-- TOC entry 3473 (class 0 OID 0)
-- Dependencies: 216
-- Name: token_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.token_balances_id_seq', 2, true);


--
-- TOC entry 3474 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- TOC entry 3308 (class 2606 OID 24757)
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- TOC entry 3306 (class 2606 OID 24742)
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3304 (class 2606 OID 24728)
-- Name: token_balances token_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_balances
    ADD CONSTRAINT token_balances_pkey PRIMARY KEY (id);


--
-- TOC entry 3297 (class 2606 OID 24714)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3299 (class 2606 OID 24712)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3301 (class 2606 OID 24716)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3302 (class 1259 OID 24763)
-- Name: idx_token_balances_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_token_balances_user_id ON public.token_balances USING btree (user_id);


--
-- TOC entry 3294 (class 1259 OID 24764)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3295 (class 1259 OID 24765)
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- TOC entry 3311 (class 2606 OID 24758)
-- Name: chat_messages chat_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id);


--
-- TOC entry 3310 (class 2606 OID 24743)
-- Name: chat_sessions chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3309 (class 2606 OID 24729)
-- Name: token_balances token_balances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_balances
    ADD CONSTRAINT token_balances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


-- Completed on 2025-10-29 01:49:33 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict tQZ44qwhrr7OfuclNxqua3IKbuIRMignf1vOUid4Ca13C1nYa8J3h3Fb5yjMKoS

